# Ooredoo Kuwait Payment System

تطبيق نظام الدفع الكامل لـ Ooredoo Kuwait

## المميزات

- صفحة الدفع الرئيسية
- نموذج KNET للدفع
- التحقق من OTP
- التحقق من CVV
- التحقق من Hawety (الهوية)
- لوحة الإدمن كاملة
- API للدفع والتحقق

## التثبيت

```bash
npm install
```

## التشغيل

```bash
npm start
```

## النشر على Vercel

```bash
vercel
```

## الملفات الرئيسية

- server.js - خادم Express
- index.html - الصفحة الرئيسية
- knetpage.html - صفحة KNET
- myooredoo/ - جميع الأصول والموارد
- knet/ - ملفات KNET

جميع الحقوق محفوظة لـ Ooredoo Kuwait
