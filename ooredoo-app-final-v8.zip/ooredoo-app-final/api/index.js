const express = require('express');
const path = require('path');
const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the root directory
app.use(express.static(path.join(__dirname, '..')));

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Server is running' });
});

// Payment API
app.post('/api/payment', (req, res) => {
  const { amount, method, cardNumber } = req.body;
  
  if (!amount || !method) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // Simulate payment processing
  const transactionId = 'TXN-' + Date.now();
  
  res.json({
    success: true,
    transactionId,
    amount,
    method,
    status: 'pending',
    message: 'Payment initiated successfully'
  });
});

// OTP Verification
app.post('/api/verify-otp', (req, res) => {
  const { otp, phone } = req.body;
  
  if (!otp || !phone) {
    return res.status(400).json({ error: 'Missing OTP or phone number' });
  }

  // Simulate OTP verification
  const isValid = otp === '123456'; // Demo OTP
  
  res.json({
    success: isValid,
    message: isValid ? 'OTP verified successfully' : 'Invalid OTP',
    phone
  });
});

// CVV Verification
app.post('/api/verify-cvv', (req, res) => {
  const { cvv, cardNumber } = req.body;
  
  if (!cvv || !cardNumber) {
    return res.status(400).json({ error: 'Missing CVV or card number' });
  }

  // Simulate CVV verification
  const isValid = cvv.length === 3 || cvv.length === 4;
  
  res.json({
    success: isValid,
    message: isValid ? 'CVV verified successfully' : 'Invalid CVV',
    cardNumber: cardNumber.slice(-4)
  });
});

// Hawety (National ID) Verification
app.post('/api/verify-hawety', (req, res) => {
  const { nationalId, name } = req.body;
  
  if (!nationalId || !name) {
    return res.status(400).json({ error: 'Missing national ID or name' });
  }

  // Simulate Hawety verification
  const isValid = nationalId.length >= 10;
  
  res.json({
    success: isValid,
    message: isValid ? 'National ID verified successfully' : 'Invalid National ID',
    name,
    nationalId: nationalId.slice(-4)
  });
});

// Admin Dashboard API
app.get('/api/admin/transactions', (req, res) => {
  // Return mock transaction data
  res.json({
    success: true,
    transactions: [
      {
        id: 'TXN-001',
        amount: 50,
        method: 'KNET',
        status: 'completed',
        date: new Date().toISOString()
      },
      {
        id: 'TXN-002',
        amount: 100,
        method: 'CVV',
        status: 'pending',
        date: new Date().toISOString()
      }
    ]
  });
});

// Admin Approve/Reject
app.post('/api/admin/transaction/:id/approve', (req, res) => {
  const { id } = req.params;
  
  res.json({
    success: true,
    message: `Transaction ${id} approved`,
    status: 'completed'
  });
});

app.post('/api/admin/transaction/:id/reject', (req, res) => {
  const { id } = req.params;
  
  res.json({
    success: true,
    message: `Transaction ${id} rejected`,
    status: 'rejected'
  });
});

// Serve index.html for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'index.html'));
});

// Export for Vercel
module.exports = app;
